"""Ispitivanje cijelog toka (popis -> oglasi -> JSON -> obavijest) na lokalnom poslužitelju. python scraper/test_pipeline.py"""
import http.server, json, os, shutil, socketserver, subprocess, sys, tempfile, threading, functools
HERE = os.path.dirname(os.path.abspath(__file__)); FX = os.path.join(HERE, 'fixtures')
rd = lambda n: open(os.path.join(FX, n), encoding='utf-8').read()
tmp = tempfile.mkdtemp()
site = os.path.join(tmp, 'www'); os.makedirs(site + '/clanci/oglasi/full')

class Q(socketserver.TCPServer):
    allow_reuse_address = True
srv = Q(('127.0.0.1', 0), functools.partial(http.server.SimpleHTTPRequestHandler, directory=site))
port = srv.server_address[1]
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
srv = Q(('127.0.0.1', 0), functools.partial(Quiet, directory=site)); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

wrap = lambda t: '<html><head><title>x</title><script>var a=1;</script></head><body><nav>Izbornik</nav><main>' + ''.join(f'<p>{l}</p>' for l in t.split('\n')) + '</main></body></html>'
open(site + '/index.html', 'w', encoding='utf-8').write(rd('index.html').replace('PORT', str(port)))
open(site + '/ministry.html', 'w', encoding='utf-8').write(rd('ministry.html').replace('PORT', str(port)))
pages = {'9000001': rd('virovitica.txt'), '9000002': rd('pgz.txt'), '9000003': rd('zabok_novine.txt'),
         '9000004': rd('ponistenje.txt') + ' ' * 0 + 'x' * 250, '9000005': 'kratko'}
for k, t in pages.items():
    open(f'{site}/clanci/oglasi/full/o{k}.html', 'w', encoding='utf-8').write(wrap(t))
open(site + '/robots.txt', 'w').write('User-agent: *\nDisallow: /clanci/oglasi/full/o9000005.html\nDisallow: /clanci/oglasi/o9000005.html\n')

data = os.path.join(tmp, 'data.json'); out = os.path.join(tmp, 'out.json'); issue = os.path.join(tmp, 'issue.md')
json.dump({'natjecaji': [{'id': 'old1', 'ustanova': 'Stari', 'link': 'x', 'parsed': True, 'vrsta': 'natjecaj', 'specs': []}]}, open(data, 'w'))
cfg = os.path.join(tmp, 'cfg.json'); json.dump({'watch_specs': [], 'watch_zupanije': []}, open(cfg, 'w'))

def run():
    return subprocess.run([sys.executable, os.path.join(HERE, 'scrape.py'), '--config', cfg, '--data', data, '--out', out, '--issue', issue,
                           '--index-url', f'http://127.0.0.1:{port}/index.html', '--ministry-url', f'http://127.0.0.1:{port}/ministry.html', '--delay', '0'],
                          capture_output=True, text=True)
fails = []
def check(n, c):
    print(('OK   ' if c else 'FAIL ') + n); (not c) and fails.append(n)

r = run(); print(r.stdout, r.stderr)
j = json.load(open(out)); by = {n['id']: n for n in j['natjecaji']}
check('izlaz 0', r.returncode == 0)
check('Virovitica: 8 specijalizacija i rok', len(by['9000001']['specs']) == 8 and by['9000001']['rok'] == '2026-09-19')
check('Virovitica: županija', by['9000001']['zupanija'] == 'Virovitičko-podravska')
check('PGŽ: ponovljeni + 3 spec.', by['9000002']['vrsta'] == 'ponovljeni' and len(by['9000002']['specs']) == 3)
check('Zabok: napomena o dnevnom listu', bool(by['9000003']['rokNapomena']))
check('robots: natječaj ostaje u popisu bez specijalizacija', by['9000005']['parsed'] is False and by['9000005']['specs'] == [])
check('Ministarstvo: dodan samo DZBPZ (Zabok je duplikat)', sum(1 for n in j['natjecaji'] if n['izvor'] == 'zdravlje.gov.hr') == 1)
check('obavijest napisana', os.path.exists(issue) and 'Virovitica' in open(issue).read())
check('stari zapis nije u izlazu (nije u popisu)', 'old1' not in by)
# drugi prolaz: ništa novo, zapisi iz spremnika
n1 = open(out).read()
r2 = run()
j2 = json.load(open(out))
check('2. prolaz: nema nove obavijesti', not os.path.exists(issue))
check('2. prolaz: isti broj zapisa', len(j2['natjecaji']) == len(j['natjecaji']))
# prazan popis -> greška
open(site + '/index.html', 'w', encoding='utf-8').write('<html><body>nema ničega</body></html>')
r3 = run(); check('prazan popis -> izlaz 3 (glasna greška)', r3.returncode == 3)
srv.shutdown(); shutil.rmtree(tmp)
print('\nSVE PROŠLO' if not fails else f'\nPALO: {fails}'); sys.exit(1 if fails else 0)
