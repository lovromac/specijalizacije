"""Testovi razbora natječaja. Pokretanje: python scraper/test_scrape.py"""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))
import scrape as S

FX = os.path.join(os.path.dirname(__file__), 'fixtures')
rd = lambda n: open(os.path.join(FX, n), encoding='utf-8').read()
fails = []


def check(name, got, want):
    ok = got == want
    print(('OK   ' if ok else 'FAIL ') + name + ('' if ok else f'\n       dobiveno: {got!r}\n       očekivano: {want!r}'))
    if not ok:
        fails.append(name)


def specs(fx):
    return [(s['kanon'], s['n']) for s in S.parse_specs(rd(fx))]


# --- specijalizacije
check('virovitica', specs('virovitica.txt'), [
    ('Abdominalna kirurgija', 1), ('Anesteziologija, reanimatologija i intenzivna medicina', 4), ('Dječja kirurgija', 1),
    ('Endokrinologija i dijabetologija', 1), ('Hitna medicina', 3), ('Internistička onkologija', 1),
    ('Klinička radiologija', 2), ('Oftalmologija i optometrija', 1)])
check('pgz (bez medicinske biokemije)', specs('pgz.txt'),
      [('Obiteljska medicina', 15), ('Ginekologija i opstetricija', 1), ('Medicina rada i sporta', 2)])
check('thalassotherapia', specs('thalassotherapia.txt'), [
    ('Kardiologija', 2), ('Klinička radiologija', 1), ('Endokrinologija i dijabetologija', 1),
    ('Fizikalna medicina i rehabilitacija', 2), ('Reumatologija', 1)])
check('pozega (opća interna, rekonstrukcijska)', specs('pozega.txt'), [
    ('Abdominalna kirurgija', 1), ('Hitna medicina', 1), ('Pedijatrija', 1), ('Opća interna medicina', 1),
    ('Opća kirurgija', 1), ('Ortopedija i traumatologija', 1),
    ('Plastična, rekonstrukcijska i estetska kirurgija', 1), ('Urologija', 1)])
check('zzjz vsž (preskoči laboratorijskog inženjera)', specs('zzjz_vsz.txt'), [('Školska i adolescentna medicina', 1)])
check('zabok (veliko slovo, dvotočka)', specs('zabok_novine.txt'), [('Hitna medicina', 2)])
check('broj riječju', specs('eksplicitni_datum.txt'), [('Psihijatrija', 1)])
check('ponistenje nema specijalizacija', specs('ponistenje.txt'), [])

# --- rok
r = S.parse_rok(rd('virovitica.txt'), '2026-09-11')
check('rok 8 dana (ne 15 ni 30 dana odluke)', r, ('2026-09-19', True, ''))
check('rok 15 dana (tiskano izdanje NN)', S.parse_rok(rd('pgz.txt'), '2026-02-18')[:2], ('2026-03-05', True))
check('rok iz dnevnog lista -> napomena', bool(S.parse_rok(rd('zabok_novine.txt'), '2026-11-04')[2]), True)
check('izričit datum', S.parse_rok(rd('eksplicitni_datum.txt'), '2026-11-04'), ('2026-11-20', False, ''))
check('bez objave nema roka', S.parse_rok(rd('virovitica.txt'), '')[0], '')

# --- vrsta, županija, kanon
check('vrsta ponovljeni', S.vrsta_of('ponovljeni natječaj'), 'ponovljeni')
check('vrsta ispravak', S.vrsta_of('ispravak dijela natječaja'), 'ispravak')
check('vrsta natječaj i poništenje', S.vrsta_of('natječaj i poništenje natječaja'), 'natjecaj_ponistenje')
check('vrsta poništenje', S.vrsta_of('poništenje'), 'ponistenje')
check('split_title', S.split_title('Opća bolnica X - ponovljeni natječaj'), ('Opća bolnica X', 'ponovljeni natječaj'))
check('zupanija OB Virovitica', S.guess_zupanija('Opća bolnica Virovitica'), 'Virovitičko-podravska')
check('zupanija DZ PGŽ', S.guess_zupanija('Dom zdravlja Primorsko-goranske županije'), 'Primorsko-goranska')
check('zupanija KBC Split', S.guess_zupanija('Klinički bolnički centar Split'), 'Splitsko-dalmatinska')
check('zupanija DZ Zagreb Zapad', S.guess_zupanija('Dom zdravlja Zagreb – Zapad'), 'Grad Zagreb')
check('zupanija ZZJZ Zagrebačke', S.guess_zupanija('Zavod za javno zdravstvo Zagrebačke županije'), 'Zagrebačka')
check('zupanija OB Zabok', S.guess_zupanija('Opća bolnica Zabok i bolnica hrvatskih veterana'), 'Krapinsko-zagorska')
check('zupanija Thalassotherapia', S.guess_zupanija('Thalassotherapia Opatija'), 'Primorsko-goranska')
check('kanon: hitne medicine', S.canon_spec('hitne medicine'), 'Hitna medicina')
check('kanon: nepoznato ostaje', S.canon_spec('sportske kardiologije'), 'Sportske kardiologije')

# --- popis
idx = rd('index.html').replace('PORT', '1')
items = S.parse_index(idx, 'http://localhost:1/')
check('index: 5 oglasa', len(items), 5)
check('index: prvi', (items[0]['id'], items[0]['ustanova'], items[0]['nn'], items[0]['objavljen'], items[0]['vrsta'], items[0]['pdf'].endswith('/9000001/pdf')),
      ('9000001', 'Opća bolnica Virovitica', 'NN 101/2026', '2026-09-11', 'natjecaj', True))
check('index: ponovljeni', (items[1]['ustanova'], items[1]['vrsta']), ('Dom zdravlja Primorsko-goranske županije', 'ponovljeni'))
check('index: ispravak', items[3]['vrsta'], 'ispravak')
mi = S.parse_ministry(rd('ministry.html').replace('PORT', '1'), 'http://localhost:1/')
check('ministarstvo: samo natječaji (ne poništenje/ispravak)', [m['objavljen'] for m in mi], ['2026-11-06', '2026-10-27'])
check('ministarstvo ~ NN isti natječaj', S.same_notice(mi[0], items[2]), True)
check('ministarstvo != drugi natječaj', S.same_notice(mi[1], items[2]), False)

print('\nSVE PROŠLO' if not fails else f'\nPALO: {len(fails)} -> {fails}')
sys.exit(1 if fails else 0)
