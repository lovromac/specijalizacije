# Specijalizacije – upute za objavu (otprilike 10 minuta, besplatno)

Ova mapa sadrži aplikaciju i „robota” koji nekoliko puta dnevno povlači nove natječaje za specijalizacije doktora medicine
i objavljuje ih u tvojoj aplikaciji. Sve radi na GitHubu (besplatno), ne trebaš imati vlastiti poslužitelj.

Izvor natječaja je popis na **spec.edo.hr** (oglasi iz Narodnih novina, osvježava se u 16 i 19 sati; vodi ga Eduard Oštarijaš).
Kao dopuna čita se i popis na stranici Ministarstva zdravstva.

## 1. Račun i repozitorij
1. Otvori **github.com** i napravi besplatan račun (ako ga nemaš).
2. Gore desno: **+ → New repository**. Ime npr. `specijalizacije`. Odaberi **Public** (besplatni GitHub Pages traži javni repozitorij;
   u njemu nema tvojih osobnih podataka – oni ostaju samo u tvom pregledniku). Klikni **Create repository**.

## 2. Učitaj datoteke
1. Raspakiraj zip.
2. U novom repozitoriju klikni **uploading an existing file** i povuci unutra **sve iz mape** (mape `site`, `scraper`, `data` i datoteke
   `config.json`, `UPUTE.md`, `.gitignore`). Klikni **Commit changes**.
3. Mapa `.github` je skrivena i često se ne prenese. Zato je dodaj ručno: **Add file → Create new file**, u polje za ime upiši točno
   `.github/workflows/natjecaji.yml`, zalijepi sadržaj datoteke `workflow-za-lijepljenje.txt` iz zipa i klikni **Commit changes**.

## 3. Uključi objavu
**Settings → Pages → Source: GitHub Actions.**

## 4. Prvo pokretanje
1. Kartica **Actions** → s lijeve strane **Natječaji (povlačenje i objava)** → **Run workflow** → **Run workflow**.
2. Nakon 1–2 minute zelena kvačica znači da je gotovo. Aplikacija je na adresi
   `https://TVOJE-KORISNICKO-IME.github.io/specijalizacije/`.
3. Otvori je. Na kartici **Natječaji** vidiš sandučić „Novi natječaji”. Gumb **Prati** prebacuje natječaj u tvoju evidenciju,
   **Odbaci** ga uklanja iz sandučića.
4. Na mobitelu otvori istu adresu pa **Dodaj na početni zaslon** – ponaša se kao prava aplikacija i radi i bez interneta.

Od tada se popis sam osvježava (ujutro, oko podne i nakon svakog osvježenja spec.edo.hr).

## 5. Obavijesti na e-poštu / mobitel
Za svaki novi natječaj robot otvori „Issue” u tvom repozitoriju i spomene te, pa GitHub šalje e-poštu (i obavijest u GitHub
aplikaciji ako je instaliraš). Prvo pokretanje namjerno ne šalje ništa.
Ako želiš obavijesti samo za neke specijalizacije ili županije, u `config.json` upiši npr.
`"watch_specs": ["Pedijatrija", "Hitna medicina"]`, `"watch_zupanije": ["Splitsko-dalmatinska"]`.
(Popis u aplikaciji uvijek sadrži sve natječaje; filter vrijedi samo za e-poštu.)
U aplikaciji, **Alarmi i podaci**, odaberi specijalizacije/županije za oznaku 🔔 i obavijesti preglednika.

## Što još treba znati
- **Rok je procjena.** Robot ga računa iz teksta natječaja (npr. „8 dana od objave u Narodnim novinama”). Uz svaki natječaj piše
  „procjena”; ako se rok računa od objave u dnevnom listu, to je navedeno. Uvijek provjeri rok u samom natječaju (gumb „Oglas”).
- **Specijalizacije se čitaju iz teksta oglasa.** Ako ih robot ne prepozna, natječaj se ipak pojavi u sandučiću s oznakom
  „Specijalizacije nisu prepoznate – otvori natječaj”, tako da ništa ne promakne.
- **Ako workflow pocrveni** (GitHub ti pošalje e-poštu), najčešće se promijenio izgled stranice spec.edo.hr. Otvori neuspjeli
  pokušaj u kartici Actions, kopiraj crveni tekst greške i pošalji ga Claudeu da prilagodi skriptu.
- **Testiranje.** Razbor natječaja testiran je na primjerima stvarnih oglasa iz NN-a, ali robot nije mogao biti isproban na
  živim stranicama iz mog okruženja. Prvi pokretanje zato pogledaj u kartici Actions (log pokazuje koliko je oglasa pročitano i
  koji nisu prepoznati).
- **Tvoji podaci** (bodovi, evidencija, bilješke) ostaju samo u pregledniku na uređaju na kojem ih upisuješ. Na telefonu i računalu
  su odvojeni; prenosi ih izvoz/uvoz kopije u „Alarmi i podaci”. Povremeno izvezi sigurnosnu kopiju.
- **Lokalno bez weba:** `site/index.html` možeš otvoriti i dvoklikom; tada sve radi osim automatskog popisa natječaja.
- Skripta šalje samo nekoliko zahtjeva (jedan u sekundi, samo za nove oglase) i poštuje `robots.txt`.
